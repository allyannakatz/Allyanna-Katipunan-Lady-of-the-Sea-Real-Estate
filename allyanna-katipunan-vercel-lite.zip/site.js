const form = document.querySelector('#inquiry-form');
const timeZoneField = document.querySelector('#timezone');
timeZoneField.value = Intl.DateTimeFormat().resolvedOptions().timeZone ?? '';
const status = document.querySelector('#form-status');
const submit = form.querySelector('button[type=submit]');

const interest = document.querySelector('#interest');
const parameters = new URLSearchParams(window.location.search);
const project = parameters.get('property');
const projectOption = Array.from(interest.options).find(option => option.dataset.project === project);
if (projectOption) {
  interest.value = projectOption.value;
  if (parameters.get('request') === 'photos') {
    form.elements.namedItem('message').value = 'Please share current site or model-unit photos for this project.';
  }
  if (parameters.get('request') === 'status') {
    form.elements.namedItem('message').value = 'Please share current availability, any ready-for-occupancy options, and expected turnover dates.';
  }
  if (parameters.get('request') === 'pricing') {
    form.elements.namedItem('message').value = 'Please share the latest pricing, availability, and payment terms.';
  }
}

if (parameters.get('request') === 'abroad') {
  form.elements.namedItem('format').value = 'Video call';
  form.elements.namedItem('message').value = 'I live overseas and would like help buying property in the Philippines from abroad.';
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  if (submit.disabled) return;

  const data = Object.fromEntries(new FormData(form));
  const missing = ['name', 'timezone', 'message'].find(field => !data[field].trim());
  if (missing) {
    status.textContent = 'Enter your name, time zone, and a short description of what you’re looking for.';
    form.elements.namedItem(missing).focus();
    return;
  }

  submit.disabled = true;
  status.textContent = 'Sending your request…';
  try {
    const response = await fetch(form.action.replace('formsubmit.co/', 'formsubmit.co/ajax/'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await response.json();
    if (!response.ok || ![true, 'true'].includes(result.success) || /activat|confirm your email/i.test(result.message ?? '')) {
      throw new Error('Submission not confirmed');
    }
    form.reset();
    timeZoneField.value = Intl.DateTimeFormat().resolvedOptions().timeZone ?? '';
    status.textContent = 'Your consultation request was submitted. Check your email for a reply.';
  } catch {
    status.textContent = 'We couldn’t confirm your request was sent. Your answers are still here. Please try again later.';
  } finally {
    submit.disabled = false;
  }
});
